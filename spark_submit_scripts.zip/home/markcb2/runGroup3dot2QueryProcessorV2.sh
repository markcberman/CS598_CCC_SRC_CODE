/usr/hdp/current/spark2-client/bin/spark-submit --driver-memory 32g --num-executors 12 --executor-memory 24g --class cs598ccc.task1.group3.Group3dot2QueryProcessorV2 --master local[12] ./cs598ccc.jar
