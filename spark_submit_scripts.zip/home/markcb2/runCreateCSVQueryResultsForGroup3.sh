/usr/hdp/current/spark2-client/bin/spark-submit --driver-memory 15g --executor-memory 42g --class cs598ccc.task1.group3.CreateCSVQueryResultsForGroup3 --master local[10] ./cs598ccc.jar
